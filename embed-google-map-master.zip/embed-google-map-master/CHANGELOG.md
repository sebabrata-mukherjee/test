# Changelog

## 2.3.0 - 2019-12-30
- Add title parameter (#70).
  - Can be used to define the `title` attribute of the map's `iframe`.

## 2.2.0 - 2019-08-17
- Add link position parameter.

## 2.1.2 - 2019-03-10
- Fix compatibility issue with Google Recaptcha when asynchronous loading of
Google Maps is enabled (#62).

## 2.1.1 - 2019-02-17
- Update Google Maps Embed API implementation (#64).
  - Update Google API base URL.
  - Add support for adding link to Google Maps and defining link label.
- Add Hungarian translation (#64).
- Fix problem with PHP7 (#47, #63)
